<?php
if (!defined('ABSPATH')) { exit; }

/**
 * Extract a reference lookup key, NOT validate or authenticate an FP payload.
 * Master membership is established only by the subsequent database lookup.
 * Unrecognized strings remain literal keys; never repair embedded FP prefixes.
 */
function arbe_fp_parse_color_query($q) {
    if (!is_scalar($q) && $q !== null) { return ''; }
    $q = strtoupper(trim(strval($q)));
    if (preg_match('/^FP::(H[0-9]{3}_L[0-9]{3}_C[0-9]{3})(?:::|\z)/', $q, $m)) {
        return $m[1];
    }
    // Keep the single-colon shorthand for literal legacy database keys too.
    // Strip one leading marker only; repeated/embedded markers are not repaired.
    if (strncmp($q, 'FP:', 3) === 0 && strncmp($q, 'FP::', 4) !== 0) {
        $short = trim(substr($q, 3));
        if (strpos($short, 'FP:') === false) { return $short; }
    }
    return $q;
}
