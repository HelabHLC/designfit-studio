<?php
/**
 * Plugin Name: ARBE FP Platform
 * Description: FP-Code to pigment formula solver with measured reference curves, Kubelka-Munk K/S mixing, SCISSOR validation, confidence scoring, one-shortcode platform build with HLC-guided solver, public material/pigment candidates, formula curves, SCISSOR overlay and registry workflow.
 * Version: 5.2.1-rc1
 * Author: ARBE λ*
 * Requires PHP: 8.1
 *
 * Shortcodes:
 * [arbe_fp_structural_solver color="H095_L090_C105"]
 * [arbe_fp_solver_result color="H095_L090_C105"]
 * [arbe_fp_solver_card color="H095_L090_C105"]
 * [arbe_fp_certificate color="H095_L090_C105"]
 * [arbe_fp_certificate_json color="H095_L090_C105"]
 * [arbe_fp_verify_certificate id="ARBE-FP-..."]
 * [arbe_fp_registry_lookup]
 * [arbe_spectral_search color="H095_L090_C105"]
 * [arbe_fp]
 */

if (!defined('ABSPATH')) { exit; }

define('ARBE_FP_SOLVER_VERSION', '5.2.1-rc1');
// Parser-only releases do not require schema work or demo reference seeding.
define('ARBE_FP_SCHEMA_VERSION', '5.2.0');
define('ARBE_FP_SOLVER_PATH', plugin_dir_path(__FILE__));
define('ARBE_FP_SOLVER_URL', plugin_dir_url(__FILE__));

require_once ARBE_FP_SOLVER_PATH . 'includes/database.php';
require_once ARBE_FP_SOLVER_PATH . 'includes/scissor.php';
require_once ARBE_FP_SOLVER_PATH . 'includes/formula-engine.php';
require_once ARBE_FP_SOLVER_PATH . 'includes/confidence.php';
require_once ARBE_FP_SOLVER_PATH . 'includes/audit.php';
require_once ARBE_FP_SOLVER_PATH . 'includes/import.php';
require_once ARBE_FP_SOLVER_PATH . 'includes/certificate.php';
require_once ARBE_FP_SOLVER_PATH . 'includes/optimizer.php';
require_once ARBE_FP_SOLVER_PATH . 'includes/solver.php';
require_once ARBE_FP_SOLVER_PATH . 'includes/diagnostics.php';
require_once ARBE_FP_SOLVER_PATH . 'includes/smoke-test.php';
require_once ARBE_FP_SOLVER_PATH . 'includes/rest-api.php';
require_once ARBE_FP_SOLVER_PATH . 'includes/admin.php';
require_once ARBE_FP_SOLVER_PATH . 'includes/hlc-acquisition.php';
require_once ARBE_FP_SOLVER_PATH . 'includes/spectral-search.php';
require_once ARBE_FP_SOLVER_PATH . 'includes/shortcodes.php';

register_activation_hook(__FILE__, 'arbe_fp_platform_maybe_upgrade');

add_action('plugins_loaded', 'arbe_fp_platform_maybe_upgrade');

function arbe_fp_platform_maybe_upgrade() {
    // Existing 5.2.0 installs have only the historical version option. Adopt
    // that schema version without rerunning DDL or inserting demo references.
    $installed_schema = get_option('arbe_fp_platform_schema_version',
        get_option('arbe_fp_platform_version', '0.0.0'));
    if (version_compare($installed_schema, ARBE_FP_SCHEMA_VERSION, '<')) {
        arbe_fp_solver_create_tables();
        arbe_fp_solver_seed_color_master();
        if (function_exists('arbe_hlc_acq_create_tables')) { arbe_hlc_acq_create_tables(); }
        $installed_schema = ARBE_FP_SCHEMA_VERSION;
    }
    if (get_option('arbe_fp_platform_schema_version', '') !== $installed_schema) {
        update_option('arbe_fp_platform_schema_version', $installed_schema);
    }
    if (get_option('arbe_fp_platform_version', '') !== ARBE_FP_SOLVER_VERSION) {
        update_option('arbe_fp_platform_version', ARBE_FP_SOLVER_VERSION);
    }
}

add_action('wp_enqueue_scripts', 'arbe_fp_solver_assets');
add_action('admin_enqueue_scripts', 'arbe_fp_solver_assets');

function arbe_fp_solver_assets() {
    wp_register_style('arbe-fp-solver-css', ARBE_FP_SOLVER_URL . 'assets/arbe-fp-solver.css', [], ARBE_FP_SOLVER_VERSION);
    wp_register_script('chartjs', 'https://cdn.jsdelivr.net/npm/chart.js', [], '4.4.1', true);
    wp_register_script('arbe-fp-solver-js', ARBE_FP_SOLVER_URL . 'assets/arbe-fp-solver.js', ['chartjs'], ARBE_FP_SOLVER_VERSION, true);
    wp_enqueue_style('arbe-fp-solver-css');
    wp_enqueue_script('chartjs');
    wp_enqueue_script('arbe-fp-solver-js');
}
?>